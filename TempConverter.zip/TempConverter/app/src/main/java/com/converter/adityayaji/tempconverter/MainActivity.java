package com.converter.adityayaji.tempconverter;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivityTag";

    RadioButton ftoc, ctof;
    TextView input, result, historyStat;
    Button convert;
    String persist;

@Override
    public void onSaveInstanceState(Bundle savedState)
    {
        super.onSaveInstanceState(savedState);
        persist=historyStat.getText().toString();
        savedState.putString("edit",persist);
    }

@Override
    public void onRestoreInstanceState(Bundle restoreState)
    {
        super.onRestoreInstanceState(restoreState);
        historyStat.setText(restoreState.getString("edit"));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ftoc = findViewById(R.id.FTOC);
        ctof = findViewById(R.id.CTOF);
        input = findViewById(R.id.input);
        result = findViewById(R.id.result);
        convert = findViewById(R.id.ConvertButton);
        historyStat = findViewById(R.id.HistoryStat);

        ftoc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d(TAG, "onClick: ftoc");
                String T1 = ((ftoc.getText().toString()));
                Toast.makeText(getApplicationContext(), "You opted " + T1, Toast.LENGTH_SHORT).show();

            }
        });

        ctof.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d(TAG, "onClick: ctof");
                String T2 = ((ctof.getText().toString()));
                Toast.makeText(getApplicationContext(), "You opted " + T2, Toast.LENGTH_SHORT).show();
            }
        });

        convert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String inputValue = input.getText().toString();

                if (inputValue.matches("")) {

                    String resValue = "";
                    result.setText(String.valueOf(resValue));

                } else {

                    if (ftoc.isChecked()) {
                        convertToCelsius(inputValue);
                    } else {
                        convertToFahrenheit(inputValue);
                    }
                }
            }
        });
    }
    private void convertToCelsius(String inputValue) {
        Double resValue = (Double.valueOf(inputValue) - 32)/1.8;
        result.setText(String.format("%.1f", resValue));
        Log.d(TAG, "convertToCelsius: ");
        historyStat.setText(String.valueOf("Fahrenheit to Celsius : " + inputValue + "->" + String.format("%.1f", resValue) + "\n" + historyStat.getText().toString()));
    }
    private void convertToFahrenheit(String inputValue) {
        Log.d(TAG, "converToFahrenheit:");
        Double resValue = (Double.valueOf(inputValue) * 1.8) + 32.0;
        result.setText(String.format("%.1f", resValue));
        historyStat.setText(String.valueOf("Celsius to Fahrenheit : " + inputValue + "->" + String.format("%.1f", resValue) + "\n" + historyStat.getText().toString()));
    }

}
