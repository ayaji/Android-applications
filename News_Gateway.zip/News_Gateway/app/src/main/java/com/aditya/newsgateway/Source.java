package com.aditya.newsgateway;

import java.io.Serializable;



public class Source implements Serializable {

    String sourceID;
    String sourceUrl;
    String sourceName;
    String sourceCategory;

    public String getsourceID() {
        return sourceID;
    }

    public void setsourceID(String sourceID) {
        this.sourceID = sourceID;
    }

    public String getSourceUrl() {
        return sourceUrl;
    }

    public void setSourceUrl(String sourceUrl) {
        this.sourceUrl = sourceUrl;
    }

    public String getSourceName() {
        return sourceName;
    }

    public void setSourceName(String sourceName) {
        this.sourceName = sourceName;
    }

    public String getSourceCategory() {
        return sourceCategory;
    }

    public void setSourceCategory(String sourceCategory) {
        this.sourceCategory = sourceCategory;
    }
}
