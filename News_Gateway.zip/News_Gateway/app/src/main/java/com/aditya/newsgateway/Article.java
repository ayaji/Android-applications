package com.aditya.newsgateway;

import java.io.Serializable;



public class Article implements Serializable {
String articleAuthor;
String articleTitle;
String articleDescription;
String articleUrlToImage;
String articlePublishedAt;
String articleUrl;

    public String getarticleUrl() {
        return articleUrl;
    }

    public void setarticleUrl(String articleUrl) {
        this.articleUrl = articleUrl;
    }

    public String getArticleAuthor() {
        return articleAuthor;
    }

    public void setArticleAuthor(String articleAuthor) {
        this.articleAuthor = articleAuthor;
    }

    public String getArticleTitle() {
        return articleTitle;
    }

    public void setArticleTitle(String articleTitle) {
        this.articleTitle = articleTitle;
    }

    public String getArticleDescription() {
        return articleDescription;
    }

    public void setArticleDescription(String articleDescription) {
        this.articleDescription = articleDescription;
    }

    public String getArticleUrlToImage() {
        return articleUrlToImage;
    }

    public void setArticleUrlToImage(String articleUrlToImage) {
        this.articleUrlToImage = articleUrlToImage;
    }

    public String getArticlePublishedAt() {
        return articlePublishedAt;
    }

    public void setArticlePublishedAt(String articlePublishedAt) {
        this.articlePublishedAt = articlePublishedAt;
    }
}
