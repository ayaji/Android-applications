package com.notes.adityayaji.notedown;

import android.content.Context;
import android.os.LocaleList;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

public class Notes implements Serializable{
    private long dateTime;
    private String content;
    private String title;

    public Notes(long dateTime,String title,String content) {
        this.dateTime = dateTime;
        this.content = content;
        this.title = title;
    }
public Notes(){}


    public long getDateTime() {
        return dateTime;
    }

    public void setDateTime(long dateTime) {
        this.dateTime = dateTime;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDateTimeFormatted(Context context){
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss",java.util.Locale.getDefault());
        sdf.setTimeZone(TimeZone.getDefault());
        return sdf.format(new Date(dateTime));
    }

}
