package com.notes.adityayaji.notedown;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

/**
 * Created by Christopher on 1/30/2017.
 */

public class MyViewHolder extends RecyclerView.ViewHolder {

    public EditText dateTime;
    public EditText title;
    public EditText content;

    public MyViewHolder(View view) {
        super(view);

        title = (EditText) view.findViewById(R.id.Title);
        content = (EditText) view.findViewById(R.id.Content);
    }

}
