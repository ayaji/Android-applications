package com.notes.adityayaji.notedown;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class NotesAdapter extends ArrayAdapter<Notes> {
    public NotesAdapter(Context context, int resource, ArrayList<Notes> notes) {
        super(context, resource, notes);
    }

@Override
    public View getView(int position, View convertView, ViewGroup parent){
       // return super.getView(position, convertView, parent);
        if(convertView == null){
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.item_note, null);

        }

        Notes notes = getItem(position);
        if(notes != null){
            TextView title = (TextView) convertView.findViewById(R.id.list_note_title);
            TextView date = (TextView) convertView.findViewById(R.id.list_note_date);
            TextView content = (TextView) convertView.findViewById(R.id.list_note_content);
            title.setText(notes.getTitle());
            date.setText(notes.getDateTimeFormatted(getContext()));
            if(notes.getContent().length()>80){
                content.setText(notes.getContent().substring(0,80));
            }else{
                content.setText(notes.getContent());
            }
        }
            return convertView;

}

}
