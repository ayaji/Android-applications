package com.aditya.yaji.knowyourgovt;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.List;


public class GovtAdapter extends RecyclerView.Adapter<GovtViewHolder> {
    MainActivity mainActivity;
    List<OurGovernment> governmentList;

    public GovtAdapter(MainActivity mainActivity, List<OurGovernment> governmentList) {
        this.mainActivity =  mainActivity;
        this.governmentList = governmentList;
    }

    @Override
    public GovtViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View thisItemsView = LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_official_list,
                parent, false);
        thisItemsView.setOnClickListener(mainActivity);
        return new GovtViewHolder(thisItemsView);
    }

    @Override
    public void onBindViewHolder(GovtViewHolder holder, int position) {
        OurGovernment ourGovernment = governmentList.get(position);
        holder.officeNameView.setText(ourGovernment.getOfficeName());
        if(ourGovernment.getOfficial().getPartyName()==null) {
            holder.officialNameView.setText(ourGovernment.getOfficial().getName());

        }
        else {

            holder.officialNameView.setText(ourGovernment.getOfficial().getName()+" ("+ ourGovernment.getOfficial().getPartyName()+")");
        }

    }

    @Override
    public int getItemCount() {
        return governmentList.size();
    }
}
