package com.aditya.yaji.knowyourgovt;

import android.net.NetworkInfo;

public interface  Callback<T> {

    void update(T result);
    NetworkInfo getNetworkInfo();
    void finish();
}
