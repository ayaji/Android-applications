package com.aditya.yaji.knowyourgovt;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;
import com.aditya.yaji.knowyourgovt.R;


public class GovtViewHolder extends RecyclerView.ViewHolder {
    public TextView officeNameView;
    public TextView officialNameView;
    public GovtViewHolder(View view) {
        super(view);
        officeNameView = (TextView) itemView.findViewById(R.id.officeNameTxtvw);
        officialNameView = (TextView) itemView.findViewById(R.id.officailNameTxtVw);
    }
}
