package com.aditya.yaji.stockwatch;


import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.widget.Toast;

import java.util.List;
import java.util.ArrayList;


public class StockDatabase extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "STOCKDATABASE";
    private static final String TABLE_NAME = "STOCK";
    private static final String SYMBOL = "STOCK_SYMBOL";
    private static final String COMPANY = "COMPANY_NAME";
    private static final int DATABASE_VERSION = 1;
    private static final String CREATE_TABLE = "CREATE TABLE " + TABLE_NAME + " ( " + SYMBOL + " TEXT not null unique, " + COMPANY +" TEXT not null)";
    private SQLiteDatabase sqLiteDatabase;
    Context context;

    public StockDatabase(Context context){
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        sqLiteDatabase = getWritableDatabase();
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public void addNewStock(Stock stock){
        ContentValues contentValues = new ContentValues();
        contentValues.put(SYMBOL, stock.getSymbol());
        contentValues.put(COMPANY, stock.getName());
        sqLiteDatabase.insert(TABLE_NAME, null, contentValues);
    }

    public void deleteStock(String stockSymbol){
        int result = sqLiteDatabase.delete(TABLE_NAME, SYMBOL +" = ?", new String[] {stockSymbol});
        if(result>0)
            Toast.makeText(context.getApplicationContext(),"Stock deleted successfully",Toast.LENGTH_LONG).show();
        else
            Toast.makeText(context.getApplicationContext(),"Something went wrong, please try again",Toast.LENGTH_LONG).show();
    }

    public List<String[]> getAllStocks(){
        List<String[]> allStocks = new ArrayList<>();
        Cursor cursor = sqLiteDatabase.query(TABLE_NAME, new String[]{SYMBOL, COMPANY}, null, null, null , null, null);
        if (cursor !=null && cursor.moveToFirst()){
            for (int i =0; i<cursor.getCount(); i++){
                allStocks.add(new String[] {cursor.getString(0), cursor.getString(1)});
                cursor.moveToNext();
            }
            cursor.close();
        }
        return allStocks;
    }
}
