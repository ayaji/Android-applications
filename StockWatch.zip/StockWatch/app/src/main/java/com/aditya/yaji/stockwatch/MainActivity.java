package com.aditya.yaji.stockwatch;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, View.OnLongClickListener {

    private ConnectivityManager connectivityManager;
    private RecyclerView recycler;
    private SwipeRefreshLayout swipeRefreshLayout;
    private StockAdapter stockAdapter;
    private StockDatabase db;
    private List<Stock> stockList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        recycler = (RecyclerView) findViewById(R.id.recycle);
        stockAdapter = new StockAdapter(this, stockList);
        recycler.setAdapter(stockAdapter);
        recycler.setLayoutManager(new LinearLayoutManager(this));
        stockAdapter.notifyDataSetChanged();

        db = new StockDatabase(this);
        swipeRefreshLayout = (SwipeRefreshLayout) findViewById(R.id.swipe);
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {

            @Override
            public void onRefresh() {
                if (isNetworkAvailable() == false || stockList.size() == 0) {
                    swipeRefreshLayout.setRefreshing(false);
                    return;
                }

                for (Stock stock : stockList) {
                    StockLoadUpdate aul = new StockLoadUpdate(MainActivity.this);
                    aul.execute(stock);
                }
                swipeRefreshLayout.setRefreshing(false);
            }
        });

        if (isNetworkAvailable()) {
            List<String[]> allStocks = db.getAllStocks();
            for (String[] strings : allStocks) {
                Stock stock = new Stock(strings[0], strings[1]);
                StockLoadData loadData = new StockLoadData(this);
                loadData.execute(stock);
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.addStockButton:
                onAddButtonClick();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void onAddButtonClick() {
        LayoutInflater inflater = LayoutInflater.from(this);
        final View view = inflater.inflate(R.layout.add_stock, null);
        final AlertDialog.Builder alertBuilder = new AlertDialog.Builder(this);
        alertBuilder.setMessage("Please Enter a Stock Symbol");
        alertBuilder.setTitle("Stocks Selection");
        alertBuilder.setView(view);
        alertBuilder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                EditText inputTextView = (EditText) view.findViewById(R.id.input);
                String input = inputTextView.getText().toString();
                if (isNetworkAvailable()){
                    if(input.isEmpty()){
                        AlertDialog.Builder alert = new AlertDialog.Builder(MainActivity.this);
                        alert.setTitle("Empty Stock name").setIcon(android.R.drawable.ic_dialog_alert);
                        alert.setMessage("Stock input cannot be empty");
                        alert.setPositiveButton("OK", null);
                        alert.show();
                    }else{
                    StockLoadSymbol loadSymbol = new StockLoadSymbol(MainActivity.this);
                    loadSymbol.execute(input);
                }}
            }
        });
        alertBuilder.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        AlertDialog alert = alertBuilder.create();
        alert.show();
    }


    public boolean isNetworkAvailable() {
        NetworkInfo netInfo = connectivityManager.getActiveNetworkInfo();
        if (netInfo != null && netInfo.isConnectedOrConnecting()) return true;
        else {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("No Network Connection");
            builder.setMessage("Stocks cannot be added without Network Connection");
            builder.setNeutralButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                }
            });
            AlertDialog alert = builder.create();
            alert.show();
            return false;
        }
    }


    public void addStock(final Stock stock) {
        for (Stock each : stockList) {
            if (each.getSymbol().equals(stock.getSymbol())) {
                AlertDialog.Builder alert = new AlertDialog.Builder(MainActivity.this);
                alert.setTitle("Duplicate Stock ").setIcon(android.R.drawable.ic_dialog_alert);
                alert.setMessage("Stock " + each.getSymbol() + " is already displayed in your list");
                alert.setPositiveButton("OK", null);
                alert.show();
                return;
            }

        }
        stockList.add(stock);
        sortStock();
        db.addNewStock(stock);
        stockAdapter.notifyDataSetChanged();
    }

    private void sortStock() {
        Collections.sort(stockList, new Comparator<Stock>() {
            @Override
            public int compare(Stock stock1, Stock stock2) {
                return stock1.getSymbol().compareTo(stock2.getSymbol());
            }
        });
    }

    public void updateStock(Stock stock) {
        int flag = 0;
        for (Stock s : stockList) {
            if (s.getSymbol().equals(stock.getSymbol())) {
                break;
            }
            flag++;
        }
        stockList.remove(flag);
        stockList.add(flag, stock);
        stockAdapter.notifyDataSetChanged();
    }

    @Override
    public void onClick(View v) {
        int position = recycler.getChildAdapterPosition(v);
        Stock stock = stockList.get(position);
        String url = this.getString(R.string.url) + stock.getSymbol();
        Intent intent = new Intent((Intent.ACTION_VIEW));
        intent.setData(Uri.parse(url));
        startActivity(intent);
    }

    @Override
    public boolean onLongClick(View v) {
        final int position = recycler.getChildAdapterPosition(v);
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Delete Stock").setIcon(android.R.drawable.ic_dialog_alert);
        builder.setMessage("Delete stock " + stockList.get(position).getSymbol());
        builder.setPositiveButton("YES", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Log.d("position: ", "" + position);
                db.deleteStock(stockList.get(position).getSymbol());
                stockList.remove(position);
                stockAdapter.notifyDataSetChanged();
            }
        });
        builder.setNegativeButton("NO", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        AlertDialog alert = builder.create();
        alert.show();
        return false;
    }
}