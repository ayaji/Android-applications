package com.aditya.yaji.stockwatch;

import android.graphics.Color;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.List;

public class StockAdapter extends RecyclerView.Adapter<StockViewHolder> {

    private List<Stock> stocks;
    private MainActivity mainActivity;

    @Override
    public StockViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.stock_list, parent, false);
        view.setOnLongClickListener(mainActivity);
        view.setOnClickListener(mainActivity);
        return new StockViewHolder(view);
    }

    public StockAdapter(MainActivity mainActivity, List<Stock> stocks) {
        this.mainActivity = mainActivity;
        this.stocks = stocks;
    }

    @Override
    public void onBindViewHolder(StockViewHolder holder, int position) {
        Stock stock = stocks.get(position);
        holder.stockName.setText(stock.getName());
        holder.stockPrice.setText(String.valueOf(stock.getPrice()));
        holder.stockSymbol.setText(stock.getSymbol());
        if (stock.getPriceChange() > 0)
        {
            holder.change.setText("▲ "+String.valueOf(stock.getPriceChange())+"("+String.valueOf(stock.getPercentChange()).substring(0,5)+"%)");
            holder.stockName.setTextColor(Color.GREEN);
            holder.stockPrice.setTextColor(Color.GREEN);
            holder.stockSymbol.setTextColor(Color.GREEN);
            holder.change.setTextColor(Color.GREEN);
        }else{
            holder.change.setText("▼ "+String.valueOf(stock.getPriceChange())+"("+String.valueOf(stock.getPercentChange()).substring(0,5)+"%)");
            holder.stockName.setTextColor(Color.RED);
            holder.stockPrice.setTextColor(Color.RED);
            holder.stockSymbol.setTextColor(Color.RED);
            holder.change.setTextColor(Color.RED);
        }
    }

    @Override
    public int getItemCount() {
        return stocks.size();
    }
}
